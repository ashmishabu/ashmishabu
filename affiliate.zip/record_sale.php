<?php
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $amount = $_POST['amount'];

    if (!empty($user_id) && !empty($amount)) {
        recordSale($user_id, $amount);
    } else {
        echo "Error: All fields are required.";
    }
}
?>

