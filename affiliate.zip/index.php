<?php
include 'functions.php';

// Fetch all users and sales to display in the table
$users = getUsers();
$sales = getSales();
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://fonts.googleapis.com/css2?family=Marcellus&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Marcellus&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
<head>
    <title>Affiliate System</title>
</head>
<body>
    <section class="sec-form-4">
        <div class="container-fluid">
            <form class="addfm qualif-tab" action="add_user.php" method="post">
                <div class="row align-items-center">
                    <div class="qualif-tab-line">
                        <h2>Add New User</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                        <div class="form-hm">
                            <div class="row align-items-center">

                                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <label for="name" class="col-sm-4 col-form-label required int-labels">Name</label> 
                                    <div class="input-container col-sm-6">
                                        <input type="text" class="form-control qual-form" id="name" name="name" required>
                                    </div>
                                </div>  
                                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <label for="inputname" class="col-sm-4 col-form-label required int-labels">Email:</label>  
                                    <div class="input-container col-sm-6">
                                        <input type="email" class="form-control qual-form" id="email"  name="email" required>   
                                    </div>
                                </div>  
                                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <label for="parent_id" class="col-sm-4 col-form-label required int-labels">Parent ID</label>  
                                    <div class="input-container col-sm-6">
                                        <input type="number" class="form-control qual-form" id="parent_id" name="parent_id">  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-container col-lg-12 justify-content-center d-flex pt">
                        <div class="qual-btns">
                            <input type="submit" value="Add User" class="btn btn-primary btn-print">
                        </div>
                    </div>
                </div>
            </form>
        

        <div class="qualif-tab">
            <h4>Users List</h4>
        </div>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Parent ID</th>
                    </tr>
                </thead>

                <?php if (!empty($users)): ?>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo ($user['id']); ?></td>
                    <td><?php echo ($user['name']); ?></td>
                    <td><?php echo ($user['email']); ?></td>
                    <td><?php echo ($user['parent_id']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr>
                    <td colspan="4">No users found</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </section>

    
    <section class="sec-form-4">
        <div class="container-fluid">
            <form class="qualif-tab" action="record_sale.php" method="post">
                <div class="row align-items-center">
                    <div class="qualif-tab-line">
                        <h2>Record Sale</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12 mb-4">
                        <div class="form-hm">
                            <div class="row align-items-center">
                                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <label for="user_id" class="col-sm-4 col-form-label required int-labels">User_ID</label> 
                                    <div class="input-container col-sm-6">
                                        <input class="form-control qual-form" type="number" id="user_id" name="user_id" required>
                                    </div>
                                </div>  
                                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <label for="amount" class="col-sm-4 col-form-label required int-labels">Amount</label>  
                                    <div class="input-container col-sm-6">
                                        <input class="form-control qual-form" type="number" step="0.01" id="amount" name="amount" required>   
                                    </div>
                                </div> 
                                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                                    <div class="qual-btns">
                                        <input type="submit" value="Record Sale" class="btn btn-primary btn-print">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="qualif-tab">
                <h4>Sales List</h4>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">User ID</th>
                      <th scope="col">Amount</th>
                    </tr>
                </thead>
                <?php if (!empty($sales)): ?>
                <?php foreach ($sales as $sale): ?>
                <tr>
                    <td><?php echo ($sale['id']); ?></td>
                    <td><?php echo ($sale['user_id']); ?></td>
                    <td><?php echo ($sale['amount']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php else: ?>
                <tr>
                    <td colspan="3">No sales found</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </section>
    
  <script src="js/bootstrap.bundle.min.js"></script>   
</body>
</html>

