<?php
include 'db.php';


// ------------Add User----------------

function addUser($name, $email, $parent_id = NULL) {
    global $conn;

    if (!is_null($parent_id)) {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE id = ?");
        $stmt->bind_param("i", $parent_id);
        $stmt->execute();
        $stmt->bind_result($parent_exists);
        $stmt->fetch();
        $stmt->close();

        if ($parent_exists == 0) {
            echo "Error: Parent ID does not exist.";
            return false;
        }
    }

    $stmt = $conn->prepare("INSERT INTO users (name, email, parent_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $name, $email, $parent_id);

    if ($stmt->execute()) {
        return $stmt->insert_id;
    } else {
        echo "Error: " . $stmt->error;
        return false;
    }

    $stmt->close();
}

function getUsers() {
    global $conn;
    $result = $conn->query("SELECT id, name, email, parent_id FROM users");
    return $result->fetch_all(MYSQLI_ASSOC);
}



// ------------Record Sale-----------------

function recordSale($user_id, $amount) {
    global $conn;

    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($user_exists);
    $stmt->fetch();
    $stmt->close();

    if ($user_exists == 0) {
        echo "Error: User ID does not exist.";
        return;
    }

    $stmt = $conn->prepare("INSERT INTO sales (user_id, amount) VALUES (?, ?)");
    $stmt->bind_param("id", $user_id, $amount);

    if ($stmt->execute()) {
        $sale_id = $stmt->insert_id;
        calculatePayouts($user_id, $sale_id, $amount);
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}



// ------------Calculate Payouts-----------------

function calculatePayouts($user_id, $sale_id, $amount) {
    global $conn;

    $payout_levels = [0.10, 0.05, 0.03, 0.02, 0.01];
    $current_user_id = $user_id;
    $level = 0;

    while ($current_user_id != NULL && $level < count($payout_levels)) {
        $stmt = $conn->prepare("SELECT parent_id FROM users WHERE id = ?");
        $stmt->bind_param("i", $current_user_id);
        $stmt->execute();
        $stmt->bind_result($parent_id);
        $stmt->fetch();
        $stmt->close();

        if ($parent_id != NULL) {
            $payout_amount = $amount * $payout_levels[$level];
            $stmt = $conn->prepare("INSERT INTO payouts (user_id, sale_id, amount) VALUES (?, ?, ?)");
            $stmt->bind_param("iid", $parent_id, $sale_id, $payout_amount);
            $stmt->execute();
            $stmt->close();
        }

        $current_user_id = $parent_id;
        $level++;
    }
}

function getSales() {
    global $conn;
    $result = $conn->query("SELECT id, user_id, amount FROM sales");
    return $result->fetch_all(MYSQLI_ASSOC);
}
?>
