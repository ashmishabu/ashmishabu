<?php
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $parent_id = !empty($_POST['parent_id']) ? $_POST['parent_id'] : NULL;

    addUser($name, $email, $parent_id);
}
?>
